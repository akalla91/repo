from ansi2html.converter import main

if __name__ == "__main__":
    main()
