.. highlight:: shell

============
Installation
============

At the command line::

    $ easy_install pyfpgrowth

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv pyfpgrowth
    $ pip install pyfpgrowth
