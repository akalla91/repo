# Code of Conduct

The Blosc community has adopted a Code of Conduct that we expect project participants to adhere to.
Please read the [full text](https://github.com/Blosc/community/blob/master/code_of_conduct.md)
so that you can understand what actions will and will not be tolerated.
