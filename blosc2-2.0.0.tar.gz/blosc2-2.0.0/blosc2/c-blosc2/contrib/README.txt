In this folder there are files used during the development of the NEON implementation of the shuffle and bitshuffle filters.
