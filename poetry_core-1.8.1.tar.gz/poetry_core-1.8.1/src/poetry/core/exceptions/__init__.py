from __future__ import annotations

from poetry.core.exceptions.base import PoetryCoreException


__all__ = ("PoetryCoreException",)
