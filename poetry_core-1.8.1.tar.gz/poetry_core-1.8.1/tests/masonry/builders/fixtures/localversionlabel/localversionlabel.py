"""Test fixture for https://github.com/python-poetry/poetry/issues/756"""
