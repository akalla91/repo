check for non-negative weigths in A

tests:
- 6 node undirected, unit length
- 12 node undirected, unit length
- 16 node undirected, random length
- 16 node directed, random length

bellman*
- cm is the index of the cluster seed associated with a nodes cluster

lloyd*
- cm is the cluster index

lloyd_cluster:
- distance is really distance to the cluster interface

lloyd_cluster_exact
- distance is to the nearest seed in any cluster
