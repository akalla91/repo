This directory contains the various files and scripts used to create the PyAMG logo.

