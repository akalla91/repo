PyAMG |version|
=================================

.. mdinclude:: README.md

Reference
=========

* :ref:`genindex`
* :ref:`modindex`

.. toctree::
    :maxdepth: 4

    ref
