# Changelog

A summary of changes for pyamg.

## [4.2.3]
- add joss paper
- update dostrings throughout
- address minor bugs
- update readthedocs
- remove pytest as an install requires
- improve testing/features in fem.py

## [4.2.2]
- update import for scipy 1.8
- add python 3.10 to CI
- fix up docstrings
