# Changelog

This is a long-winded preamble that explains versioning and backwards-compatibility guarantees.
Your don't want this as part of your PyPI readme!

Note that there's issue/PR IDs behind the changelog entries.
Wouldn't it be nice if they were links in your PyPI readme?

<!-- changelog follows -->


## 1.1.0 - 2022-08-04

### Added

- Neat features. #4
- Here's a [GitHub-relative link](README.md) -- that would make no sense in a PyPI readme!

### Fixed

- Nasty bugs. #3


## 1.0.0 - 2021-12-16

### Added

- Everything. #2


## 0.0.1 - 2020-03-01

### Removed

- Precedency. #1
