# TSNE Change Log

## [0.3.0]

- Organized package structure
- Fixed multiple installation issues
- Added GitHub Actions
