from .kprototypes import KPrototypes, KPrototypesModel
