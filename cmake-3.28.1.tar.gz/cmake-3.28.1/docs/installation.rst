============
Installation
============

Install package with pip
------------------------

To install with pip::

    $ pip install cmake

Install from source
-------------------

See :doc:`building`

Dependencies
------------

Python Packages
^^^^^^^^^^^^^^^

The development dependencies (for testing and coverage) are:

.. include:: ../requirements-dev.txt
   :literal:
