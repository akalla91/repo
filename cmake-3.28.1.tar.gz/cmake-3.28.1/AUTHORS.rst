=======
Credits
=======

Please see the GitHub project page at https://github.com/scikit-build/cmake-python-distributions/graphs/contributors
