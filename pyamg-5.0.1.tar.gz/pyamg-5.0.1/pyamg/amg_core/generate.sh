./bindthem.py air.h
./bindthem.py evolution_strength.h
./bindthem.py graph.h
./bindthem.py krylov.h
./bindthem.py linalg.h
./bindthem.py relaxation.h
./bindthem.py ruge_stuben.h
./bindthem.py smoothed_aggregation.h
