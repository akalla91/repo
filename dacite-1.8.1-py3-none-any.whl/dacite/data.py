from typing import Mapping, Any

Data = Mapping[str, Any]
