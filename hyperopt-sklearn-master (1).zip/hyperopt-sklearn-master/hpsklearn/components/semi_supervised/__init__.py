from ._label_propagation import \
    label_propagation, \
    label_spreading
