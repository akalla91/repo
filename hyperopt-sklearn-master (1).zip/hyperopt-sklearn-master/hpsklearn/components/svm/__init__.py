from ._classes import \
    linear_svc, \
    linear_svr, \
    nu_svc, \
    nu_svr, \
    one_class_svm, \
    svc, \
    svr
