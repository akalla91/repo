from ._classification import \
    k_neighbors_classifier, \
    radius_neighbors_classifier

from ._nearest_centroid import nearest_centroid

from ._regression import \
    k_neighbors_regressor, \
    radius_neighbors_regressor
