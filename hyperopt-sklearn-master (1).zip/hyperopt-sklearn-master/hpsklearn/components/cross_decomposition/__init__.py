from ._pls import \
    cca, \
    pls_canonical, \
    pls_regression
