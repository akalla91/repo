from ._gpc import gaussian_process_classifier
from ._gpr import gaussian_process_regressor
