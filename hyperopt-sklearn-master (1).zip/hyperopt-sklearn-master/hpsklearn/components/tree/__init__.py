from ._classes import \
    decision_tree_classifier, \
    decision_tree_regressor, \
    extra_tree_classifier, \
    extra_tree_regressor
