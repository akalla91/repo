# Contribution Guidelines

Contributions here will go through a standard review process
to be promoted to standard types. Contributions made
to the contrib folder will also receive help / guidance whenever
requested.


TODO:
* Add reference in the docs