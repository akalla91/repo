phik package
============

Subpackages
-----------

.. toctree::

    phik.decorators

Submodules
----------

phik.betainc module
-------------------

.. automodule:: phik.betainc
    :members:
    :undoc-members:
    :show-inheritance:

phik.binning module
-------------------

.. automodule:: phik.binning
    :members:
    :undoc-members:
    :show-inheritance:

phik.bivariate module
---------------------

.. automodule:: phik.bivariate
    :members:
    :undoc-members:
    :show-inheritance:

phik.data\_quality module
-------------------------

.. automodule:: phik.data_quality
    :members:
    :undoc-members:
    :show-inheritance:

phik.definitions module
-----------------------

.. automodule:: phik.definitions
    :members:
    :undoc-members:
    :show-inheritance:

phik.entry\_points module
-------------------------

.. automodule:: phik.entry_points
    :members:
    :undoc-members:
    :show-inheritance:

phik.outliers module
--------------------

.. automodule:: phik.outliers
    :members:
    :undoc-members:
    :show-inheritance:

phik.phik module
----------------

.. automodule:: phik.phik
    :members:
    :undoc-members:
    :show-inheritance:

phik.report module
------------------

.. automodule:: phik.report
    :members:
    :undoc-members:
    :show-inheritance:

phik.resources module
---------------------

.. automodule:: phik.resources
    :members:
    :undoc-members:
    :show-inheritance:

phik.significance module
------------------------

.. automodule:: phik.significance
    :members:
    :undoc-members:
    :show-inheritance:

phik.simulation module
----------------------

.. automodule:: phik.simulation
    :members:
    :undoc-members:
    :show-inheritance:

phik.statistics module
----------------------

.. automodule:: phik.statistics
    :members:
    :undoc-members:
    :show-inheritance:

phik.version module
-------------------

.. automodule:: phik.version
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: phik
    :members:
    :undoc-members:
    :show-inheritance:
