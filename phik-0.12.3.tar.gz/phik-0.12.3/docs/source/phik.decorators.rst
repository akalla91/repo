phik.decorators package
=======================

Submodules
----------

phik.decorators.pandas module
-----------------------------

.. automodule:: phik.decorators.pandas
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: phik.decorators
    :members:
    :undoc-members:
    :show-inheritance:
