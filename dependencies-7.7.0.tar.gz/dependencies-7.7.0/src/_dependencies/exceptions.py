class DependencyError(Exception):
    """Broken dependencies configuration error."""

    pass
