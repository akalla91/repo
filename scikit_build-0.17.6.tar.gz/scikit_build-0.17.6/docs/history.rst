.. include:: ../CHANGES.rst

History
-------

PyCMake was created at SciPy 2014 in response to general difficulties building
C++ and Fortran based Python extensions across platforms.  It was renamed to
"scikit-build" in 2016.
