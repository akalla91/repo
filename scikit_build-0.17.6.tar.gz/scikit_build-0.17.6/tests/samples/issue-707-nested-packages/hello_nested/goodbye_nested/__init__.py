from __future__ import annotations

from ._goodbye_nested import goodbye

__all__ = ("goodbye",)
