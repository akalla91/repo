from __future__ import annotations


def who():
    return "world"
