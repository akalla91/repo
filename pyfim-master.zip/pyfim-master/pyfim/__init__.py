__version__ = "0.2"

from pyfim import config
defaults = config.default_parameters

from pyfim.core import Experiment, Collection, TwoChoiceExperiment