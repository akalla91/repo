package org.jpype.late;

public class Test
{
	public int field = 5;

	public String method()
	{
		return "Yes";
	}
}
