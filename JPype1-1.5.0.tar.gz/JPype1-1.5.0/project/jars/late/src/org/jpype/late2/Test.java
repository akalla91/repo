package org.jpype.late2;

public class Test
{
	public int field = 6;

	public String method()
	{
		return "No";
	}
}
