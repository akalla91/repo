package org.jpype.missing;

public class Test
{
}

