package org.jpype.mrjar;

public class B
{
	public String call()
	{
		return "7";
	}
}
