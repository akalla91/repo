package org.jpype.mrjar;

public class A
{
}
