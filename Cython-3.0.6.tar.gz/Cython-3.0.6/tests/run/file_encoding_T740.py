# encoding: koi8-r
# mode: run
# ticket: t740
"""
>>> wtf
'wtf'
"""

wtf = 'wtf'
