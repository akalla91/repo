import cython

cython.declare(x=cython.int, y=cython.double)  # cdef int x; cdef double y
